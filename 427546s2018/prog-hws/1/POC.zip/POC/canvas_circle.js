
var canvas = document.querySelector('canvas')
var ctx = canvas.getContext('2d');
canvas.width = window.innerWidth/4 * 3;
canvas.height = window.innerHeight/4 * 3;
ctx.fillStyle = 'blue';


var DrawPixel = function (x, y) {
  ctx.fillRect(x, y, 1, 1);
}

var DrawCirle = function (x0, y0, radius) {
    var x = radius;
    var y = 0;
    var d = 1 - x;
  
    while (x >= y) {
        DrawPixel(x + x0, y + y0);
        DrawPixel(y + x0, x + y0);
        DrawPixel(-x + x0, y + y0);
        DrawPixel(-y + x0, x + y0);
        DrawPixel(-x + x0, -y + y0);
        DrawPixel(-y + x0, -x + y0);
        DrawPixel(x + x0, -y + y0);
        DrawPixel(y + x0, -x + y0);
        y++;
    
        if (d < 0) {
            d += 2 * y + 1;
        }
        else {
            x--;
            d += 2 * (y - x + 1);
        }
    } // end-while
};

DrawCirle(120, 120, 30);