
var canvas = document.querySelector('canvas')
var ctx = canvas.getContext('2d');
canvas.width = window.innerWidth/4 * 3;
canvas.height = window.innerHeight/4 * 3;
ctx.fillStyle = 'blue';

console.log("before");

var DrawPixel = function (x, y) {
  ctx.fillRect(x, y, 1, 1);
}

var Swap = function(a, b){
    return [b, a];
    //var c=a, a=b, b=c;
}

var DrawLine = function (x0, y0, x1, y1) {
    //var maxY = canvas.height;
   // console.log(maxY);
    var dx = Math.abs(x1 - x0);
    var dy = Math.abs(y1 - y0);

    var slopegt1 = 0; //0: false, 1: true

    if(dy > dx){
        console.log(x1);
        [x0, y0] = [y0, x0];
        [x1, y1] = [y1, x1];
        [dx, dy] = [dy, dx];
        slopegt1 = 1;
        console.log(x1);
    }
    if(x0 > x1){
        [x0, x1] = [x1, x0];
        [y0, y1] = [y1, y0];
    }
    if(y0 > y1)
        incY = -1;
    else
        incY = 1;
    
    d = 2 * dy -dx;
    incE = 2 * dy;
    incNE = 2 * (dy -dx);
    DrawPixel(x0, y0);
    console.log("Pixel drawn at",y0);
    while (x0 < x1) {
        if(d <= 0){   //E
            d = d + incE;}
        else{       //NE
            d += incNE;
            y0 += incY;
        }
        x0 += 1;
        if(slopegt1 == 1)
            DrawPixel(y0, x0);  //DrawPixel(y0, maxY - x0);
        else
            DrawPixel(x0, y0);  //DrawPixel(x0, maxY - y0);
    } // end-while
};

DrawLine(100, 200, 30, 10);
/*DrawLine(100, 200, 100, 10);
DrawLine(10, 20, 200, 10);
DrawLine(0, 0, 200, 300); */
