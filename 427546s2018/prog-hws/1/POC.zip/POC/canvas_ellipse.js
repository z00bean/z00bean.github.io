
var canvas = document.querySelector('canvas')
var ctx = canvas.getContext('2d');
canvas.width = window.innerWidth/4 * 3;
canvas.height = window.innerHeight/4 * 3;
ctx.fillStyle = 'blue';

console.log("before");

var DrawPixel = function (x, y) {
  ctx.fillRect(x, y, 1, 1);
}

var Swap = function(a, b){
    return [b, a];
    //var c=a, a=b, b=c;
}

var DrawEllipse = function (xc, yc, rx, ry) {
    //Region 1
   p=ry*ry-rx*rx*ry+rx*rx/4;
   x=0;y=ry;
   while(2.0*ry*ry*x <= 2.0*rx*rx*y)
   {
	if(p < 0)
	{
		x++;
		p = p+2*ry*ry*x+ry*ry;
	}
	else
	{
		x++;y--;
		p = p+2*ry*ry*x-2*rx*rx*y-ry*ry;
	}
	DrawPixel(xc+x,yc+y);
	DrawPixel(xc+x,yc-y);
	DrawPixel(xc-x,yc+y);
	DrawPixel(xc-x,yc-y);
   }
    //Region 2
    p=ry*ry*(x+0.5)*(x+0.5)+rx*rx*(y-1)*(y-1)-rx*rx*ry*ry;
    while(y > 0)
    {
        if(p <= 0)
        {
            x++;y--;
            p = p+2*ry*ry*x-2*rx*rx*y+rx*rx;
        }
        else
        {
            y--;
            p = p-2*rx*rx*y+rx*rx;
        }
        DrawPixel(xc+x,yc+y);
        DrawPixel(xc+x,yc-y);
        DrawPixel(xc-x,yc+y);
        DrawPixel(xc-x,yc-y);
    }

};

DrawEllipse(0, 0, 30, 80);